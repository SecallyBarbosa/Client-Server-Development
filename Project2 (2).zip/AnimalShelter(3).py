from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        USER = 'aacuser'
        PASS = 'user1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31998
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        if data is not None:
            insertData = self.database.animals.insert_one(data)  # data should be dictionary 
            if insertData is not None:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
    def read(self, entry):
        if entry is not None:
            found = self.database.animals.find(entry,{"id":False})
            return found
        else:
            raise Exception("Nothing to save, because data parameter is empty")  
            
def update(self, data,change):
    if data is not None:
        return self.database.animals.update(data,{"$set":change})
    else:
        print('Nothing to update, because sata parameter is empty')
        return False
        
def delete(self, deleteData):
    if deleteData is not None:
        if deleteData:
            result = self.database.animals.delete_one(deleteData)
    else:
        raise Exception("Nothing to update, remove is empty")